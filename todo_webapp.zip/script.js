let items = [];

function extractItems() {
  const text = document.getElementById("inputText").value;
  const lines = text.split(/\n|\.\s/);
  items = lines.filter(line => /(should|need to|must|action|todo|task)/i.test(line));
  renderList();
}

function renderList() {
  const list = document.getElementById("todoList");
  list.innerHTML = "";
  items.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item.trim();
    list.appendChild(li);
  });
}

function exportCSV() {
  let csvContent = "data:text/csv;charset=utf-8,Action Item\n";
  items.forEach(item => {
    csvContent += item.replace(/,/g, " ") + "\n";
  });
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "todo_list.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
